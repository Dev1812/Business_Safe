  </div>
  <div class="clear"></div>
  <div class="footer">
	<div class="banner_wrap float_r">
	  <a href="//digitalwind.ru" target="_blank">
      <img src="//digitalwind.ru/images/ru_logo_17.jpg" title="//digitalwind.ru" border="0" alt="//digitalwind.ru" width="143" height="56">
	  </a>
	</div>
    <a class="footer_link" href="/about">О сайте</a>
    <!--<a class="footer_link" href="/shares">Акции</a>-->
    <a class="footer_link" href="/companies">Корпорации</a>
    <a class="footer_link" href="/business_man">Бизнесмены</a>
    <a class="footer_link" href="/articles">Статьи</a>
    <div style="color:#333;padding-top:3px;">
      <?=date('Y');?> © Сайт о бизнесе и его защите
	  <div style="color:#808080;">
	    СГТУ, ИФСТ-12, Исаев Тимур
	  </div>
    </div>
  </div>
</div>
</body>
</html>